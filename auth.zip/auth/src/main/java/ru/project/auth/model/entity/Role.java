package ru.project.auth.model.entity;

public enum Role {
    ADMIN,
    USER
}
